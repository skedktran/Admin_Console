({
    doInit : function(component, event, helper) {
        var action = component.get("c.generatePdf");
        action.setParams({
            "auditId": component.get("v.recordId")
        });

        // Configure response handler
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var newAttachment = response.getReturnValue();
                component.set("v.newAttachment", newAttachment);
            } else {
                console.log('Problem generating pdf, response state: ' + state);
            }
        });
        $A.enqueueAction(action);
    },
    
    viewPdf: function (component, event, helper) { 
        var newAttachment = component.get("v.newAttachment");
		console.log('new attachment Id');
        console.log(newAttachment.Id);
        var navEvt = $A.get("e.force:navigateToSObject");
        navEvt.setParams({
            "recordId": newAttachment.Id,
            "slideDevName": "related"
        });
        navEvt.fire();
    },
    
    navigateToRecord : function(component , event, helper){
        window.open('/' + event.getParam('recordId'));  
    }
    
})