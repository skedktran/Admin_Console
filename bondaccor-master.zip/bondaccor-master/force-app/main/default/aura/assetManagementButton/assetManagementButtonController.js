({
	doInit: function(component, event, helper) {
		// var recordId = component.get("v.recordId");
		// console.log('doInit 222', component, recordId);
		window.addEventListener('message', helper.receiveMessage.bind(null, component, helper));
		// console.log('getJobDetailAction', recordId);
		// var getJobDetailAction = component.get('c.getJobDetail');
		// getJobDetailAction.setParams({jobId: recordId});
		// getJobDetailAction.setCallback(this, function (response) {
		// 	console.log('getJobDetailAction result', response);
		// 	var state = response.getState();
		// 	if (state === "SUCCESS") {
		// 		console.log('return value', response.getReturnValue());
		// 		var job = JSON.parse(response.getReturnValue());
		// 		if (job.data) {
		// 			job = job.data;
		// 		}
		// 		if (job && job.jobType === 'Consultation') {
		// 			setTimeout(function () {
		// 				helper.showButton(component, helper);
		// 			}, 1000);
		// 		}
		// 	}
		// });
		// $A.enqueueAction(getJobDetailAction);
	},
	closeModal:function(component, event, helper){
		console.log('closeModal 222');
		component.set('v.ifmsrc', '');
		helper.hideModal(component, helper);
	},
	openModal: function(component, event, helper) {
		console.log('openModal 222');
		
		var recordId = component.get("v.recordId");
        var visualForcePage = component.get("v.visualForcePage");
		var ifmsrc = '/apex/'+visualForcePage+'?id='+recordId + '&modal=1&openFromBrowser=1&_t=' + Date.now();
		
		console.log('ifmsrc 222', ifmsrc);
		component.set('v.ifmsrc', ifmsrc);
		
		helper.showModal(component, helper);
	},
})