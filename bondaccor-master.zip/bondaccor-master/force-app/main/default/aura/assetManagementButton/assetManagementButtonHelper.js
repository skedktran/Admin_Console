({
  showModal: function(component, helper) {
		console.log('showModal 111');
		var nodes1 = document.querySelectorAll('.skedInstallationSchedulingModal');
		var nodes2 = document.querySelectorAll('.skedInstallationSchedulingModalBackdrop');
		for (var i = 0; i < nodes1.length; i++) {
			nodes1[i].classList.add('slds-fade-in-open');
		}
		for (var j = 0; j < nodes2.length; j++) {
			nodes2[j].classList.add('slds-backdrop--open');
		}
  },
  hideModal: function(component, helper) {
		console.log('hideModal 111 111');
		var nodes1 = document.querySelectorAll('.skedInstallationSchedulingModal');
		var nodes2 = document.querySelectorAll('.skedInstallationSchedulingModalBackdrop');
		for (var i = 0; i < nodes1.length; i++) {
			nodes1[i].classList.remove('slds-fade-in-open');
		}
		for (var j = 0; j < nodes2.length; j++) {
			nodes2[j].classList.remove('slds-backdrop--open');
		}
	},
	showButton: function (component, helper) {
		console.log('showButton');
		var nodes1 = document.querySelectorAll('.skedInstallationSchedulingButton');
		console.log('nodes1', nodes1);
		if (nodes1 && nodes1.length > 0) {
			for (var i = 0; i < nodes1.length; i++) {
				nodes1[i].classList.remove('slds-hide');
			}
		}
	},
  receiveMessage: function(component, helper, event) {
		console.log('receiveMessage 111', event);
		var data = event.data;
		if (data !== null && typeof data === 'object') {
				console.log('eventName 111', data.eventName);
				if (data.eventName && data.eventName === 'sked:iframe:closeModal') {
						console.log('hideModal 111');
						helper.hideModal(component, helper);
						if (event.data && event.data.message && event.data.message !== 'cancel') {
							if (event.data.message.indexOf('redirectToJob:') > -1) {
								var jobId = event.data.message.replace('redirectToJob:', '');
								if ((typeof window.sforce != 'undefined') && window.sforce && (!!window.sforce.one)) {
								  window.sforce.one.navigateToSObject(jobId);
								} else {
									// window.location.href = '/lightning/r/sked__Job__c/' + jobId + '/view';
									var navEvt = $A.get('e.force:navigateToSObject');
									navEvt.setParams({
										recordId: jobId,
									});
									navEvt.fire();
								}
							} else {
								window.location.reload();
							}
						}
				}
		}
  }
})