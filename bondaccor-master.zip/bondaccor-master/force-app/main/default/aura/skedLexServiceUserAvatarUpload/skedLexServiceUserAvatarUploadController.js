({  
    onInit: function(component) {
        var action = component.get("c.getProfilePicture"); 
        action.setParams({
            parentId: component.get("v.recordId"),
        });
        action.setCallback(this, function(a) {
            var contentVersion = a.getReturnValue();
            console.log(contentVersion);
            if (contentVersion && contentVersion.Id) {
	            component.set('v.pictureSrc', '/sfc/servlet.shepherd/version/renditionDownload?rendition=ORIGINAL_Png&versionId=' 
                                                  + contentVersion.Id);
            }
        });
        $A.enqueueAction(action); 
    },
    
    onDragOver: function(component, event) {
        event.preventDefault();
    },

    onDrop: function(component, event, helper) {
		event.stopPropagation();
        event.preventDefault();
        event.dataTransfer.dropEffect = 'copy';
        var files = event.dataTransfer.files;
        if (files.length > 1) {
            return alert("You can only upload one profile picture.");
        }
        helper.readFile(component, helper, files[0]);
	}
    
})