export class skedResourceService {

    static getResourceTags(resourceTags) {
        if (resourceTags) {
            let tags = [];
            resourceTags.forEach(function(resTag) {
                tags.push(resTag.sked__Tag__r.Name);
            });
            return tags.join(', ');
        }
        return '';
    }

}