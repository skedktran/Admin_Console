import { LightningElement, track, api } from 'lwc';
import findRecords from '@salesforce/apex/skedUtils.findRecords';

export default class slwcCustomLookup extends LightningElement {
    @track records;
    @track error;
    @track selectedRecord;
    @api index;
    @api iconName;
    @api objectName;
    @api searchField;
    @api label;
    @api isRequired;

    handleOnchange(event){
        const searchKey = event.detail.value;
        if (searchKey !== undefined && searchKey !== '') {
            findRecords({
                searchKey : searchKey, 
                objectName : this.objectName, 
                searchField : this.searchField
            })
            .then(result => {
                this.records = result;
                for(let i = 0; i < this.records.length; i++){
                    const rec = this.records[i];
                    this.records[i].Name = rec[this.searchField];
                }
                this.error = undefined;
            })
            .catch(error => {
                this.error = error;
                this.records = undefined;
            });
        }
    }

    handleSelect(event){
        const selectedRecordId = event.detail;
        this.selectedRecord = this.records.find(record => record.Id === selectedRecordId);

        let selectedRec = {
            detail : { recordId : selectedRecordId }
        }
        const selectedRecordEvent = new CustomEvent("selectedrec", selectedRec);
        this.dispatchEvent(selectedRecordEvent);
    }

    handleRemove(event){
        event.preventDefault();
        this.selectedRecord = undefined;
        this.records = undefined;
        this.error = undefined;

        let selectedRec = {
            detail : { recordId : undefined }
        }
        const selectedRecordEvent = new CustomEvent("selectedrec", selectedRec);
        this.dispatchEvent(selectedRecordEvent);
    }
}