import { LightningElement, api, track } from 'lwc';

export default class SlwcPaginationBar extends LightningElement {
    @api totalrecords;  
    @api currentpage;  
    @api pagesize;

    get showFirstButton() {
        return this.currentpage === 1 ? true : false;
    }

    get showLastButton() {
        return Math.ceil(this.totalrecords / this.pagesize) === this.currentpage ? true : false;
    }

    handlePrevious() {
        this.dispatchEvent(new CustomEvent('previous'));
    }
    handleNext() {
        this.dispatchEvent(new CustomEvent('next'));
    }
    handleFirst() {
        this.dispatchEvent(new CustomEvent('first'));
    }
    handleLast() {
        this.dispatchEvent(new CustomEvent('last'));
    }
}