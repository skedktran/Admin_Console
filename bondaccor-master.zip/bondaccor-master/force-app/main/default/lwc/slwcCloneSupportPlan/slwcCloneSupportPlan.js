import { LightningElement, api, wire, track } from "lwc";
import { NavigationMixin } from "lightning/navigation";
import { ShowToastEvent } from "lightning/platformShowToastEvent";
import { getRecord, getFieldValue, createRecord } from "lightning/uiRecordApi";
import isAnyOtherDraft from "@salesforce/apex/skedLexSupportPlanController.isAnyOtherDraft";

import SUPPORT_PLAN_OBJECT from "@salesforce/schema/skedHC__Support_Plan__c";
import NAME_FIELD from "@salesforce/schema/skedHC__Support_Plan__c.Name";
import STATUS_FIELD from "@salesforce/schema/skedHC__Support_Plan__c.skedHC__Status__c";
import ACCOUNT_FIELD from "@salesforce/schema/skedHC__Support_Plan__c.skedHC__Account__c";
import ACCOUNT_NAME_FIELD from "@salesforce/schema/skedHC__Support_Plan__c.skedHC__Account__r.Name";
import CLONED_FROM_FIELD from "@salesforce/schema/skedHC__Support_Plan__c.sked_Cloned_From__c";
import CLONE_SUPPORT_GUIDANCE_FIELD from "@salesforce/schema/skedHC__Support_Plan__c.sked_Clone_Support_Guidance_Records__c";
import CLONE_OUTCOME_FIELD from "@salesforce/schema/skedHC__Support_Plan__c.sked_Clone_Outcome_Records__c";

export default class SlwcCloneSupportPlan extends NavigationMixin(
  LightningElement
) {
  @api recordId;
  @track cloneSupportGuidanceRecords;
  @track cloneOutcomeRecords;
  @track showWarning;
  status = "Draft";
  showSpinner = false; // BA-999

  constructor() {
    super();
    this.cloneSupportGuidanceRecords = true;
    this.cloneOutcomeRecords = true;
    this.showWarning = false;
  }

  connectedCallback() {
    Promise.all([isAnyOtherDraft({ supportPlanId: this.recordId })]).then(
      ([isAnyOtherDraftResult]) => {
        this.showWarning = isAnyOtherDraftResult;
      }
    );
  }

  @wire(getRecord, {
    recordId: "$recordId",
    fields: [NAME_FIELD, STATUS_FIELD, ACCOUNT_FIELD, ACCOUNT_NAME_FIELD]
  })
  record;

  get name() {
    return getFieldValue(this.record.data, NAME_FIELD);
  }

  get accountId() {
    return getFieldValue(this.record.data, ACCOUNT_FIELD);
  }

  get accountName() {
    return getFieldValue(this.record.data, ACCOUNT_NAME_FIELD);
  }

  handleOptionClicked(event) {
    if (event.target.name === "cloneSupportGuidanceRecords") {
      this.cloneSupportGuidanceRecords = event.target.checked;
    } else if (event.target.name === "cloneOutcomeRecords") {
      this.cloneOutcomeRecords = event.target.checked;
    }
  }

  btnCancelClicked() {
    const closeModalEvent = new CustomEvent("closemodal", {});
    this.dispatchEvent(closeModalEvent);
  }

  btnCloneClicked() {
    this.showSpinner = true; // BA-999
    const fields = {};
    fields[ACCOUNT_FIELD.fieldApiName] = this.accountId;
    fields[STATUS_FIELD.fieldApiName] = this.status;
    fields[CLONED_FROM_FIELD.fieldApiName] = this.recordId;
    fields[CLONE_SUPPORT_GUIDANCE_FIELD.fieldApiName] =
      this.cloneSupportGuidanceRecords;
    fields[CLONE_OUTCOME_FIELD.fieldApiName] = this.cloneOutcomeRecords;

    const recordInput = { apiName: SUPPORT_PLAN_OBJECT.objectApiName, fields };
    createRecord(recordInput)
      .then((supportPlan) => {
        this.showSpinner = false; // BA-999
        const closeModalEvent = new CustomEvent("closemodal", {});
        this.dispatchEvent(closeModalEvent);

        this.dispatchEvent(
          new ShowToastEvent({
            message: "Support Plan" + this.name + " was cloned.",
            variant: "success"
          })
        );

        this[NavigationMixin.Navigate]({
          type: "standard__recordPage",
          attributes: {
            recordId: supportPlan.id,
            objectApiName: "skedHC__Support_Plan__c",
            actionName: "view"
          }
        });
      })
      .catch((error) => {
        this.showSpinner = false; // BA-999
        this.dispatchEvent(
          new ShowToastEvent({
            title: "Error cloning support plan.",
            message: error.body.message,
            variant: "error"
          })
        );
      });
  }

  errorCallback(error, stack) {
    var err = error;
  }
}
