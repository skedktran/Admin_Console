const skedConstants = {
    ASSET_ALLOCATION_STATUS_ASSIGNED: 'Assigned'
}

export {
    skedConstants
}