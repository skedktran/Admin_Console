import { LightningElement, track, api } from 'lwc';

export default class slwcCustomLookupSearch extends LightningElement {
    @track searchKey;
    @api label;

    handleChange(event){
        const searchKey = event.target.value;
        event.preventDefault();
        const searchEvent = new CustomEvent('change', { detail : searchKey });
        this.dispatchEvent(searchEvent);
    }
}