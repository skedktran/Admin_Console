import { LightningElement, api, track } from 'lwc';

export default class SlwcAssignAssetModal extends LightningElement {
    @api isOpenedModal;

    @track assignmentNotes;
    @track startDate;
    @track endDate;

    handleChange(evt) {
        switch (evt.target.name) {
            case 'assignmentNotes':
                this.assignmentNotes = evt.target.value;
                break;
            case 'startDate':
                this.startDate = evt.target.value;
                break;
            case 'endDate':
                this.endDate = evt.target.value;
                break;
            default:
                break;
        }
    }

    closeModal() {
        this.dispatchEvent(new CustomEvent('close'));
    }

    saveModal() {
        var event = new CustomEvent('save', {
            detail: {
                assignmentNotes: this.assignmentNotes,
                endDate: this.endDate,
                startDate: this.startDate
            }
        });
        this.dispatchEvent(event);
    }
}