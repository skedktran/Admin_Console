import { LightningElement, api, track } from 'lwc';
import { NavigationMixin } from 'lightning/navigation';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import createAudit from '@salesforce/apex/skedLexAuditController.createAudit';

export default class slwcCreateAuditFromTemplate extends NavigationMixin(LightningElement) {
    @api recordId;
    @track accountId;

    handleSelectAccount(event) {
        this.accountId = event.detail.recordId;
    }

    btnCancelClicked() {
        this.closeModal();
    }

    btnCreateClicked() {
        if (this.accountId) {
            createAudit(
                { 
                    templateId: this.recordId, 
                    accountId: this.accountId 
                })
                .then(audit => {
                    this.closeModal();
    
                    this.dispatchEvent(
                        new ShowToastEvent({
                            message: 'Audit ' + audit.Name + ' was created.',
                            variant: 'success'
                        }),
                    );
    
                    this[NavigationMixin.Navigate]({
                        type: 'standard__recordPage',
                        attributes: {
                            recordId: audit.Id,
                            objectApiName: "sked_Audit__c",
                            actionName: "view"
                        },
                    });
                })
                .catch(error => {
                    this.dispatchEvent(
                        new ShowToastEvent({
                            title: 'Error creating audit.',
                            message: error.body.message,
                            variant: 'error',
                        }),
                    );
                });
        }
        else {
            this.dispatchEvent(
                new ShowToastEvent({
                    title: 'Error creating audit.',
                    message: 'Account is required.',
                    variant: 'error',
                }),
            );
        }
    }

    closeModal() {
        const closeModalEvent = new CustomEvent('closemodal', {});
        this.dispatchEvent(closeModalEvent);
    }
}