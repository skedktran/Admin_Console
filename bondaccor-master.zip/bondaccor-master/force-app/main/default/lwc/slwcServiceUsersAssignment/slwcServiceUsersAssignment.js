import { LightningElement, track, api } from 'lwc';
import { skedAssetLocationService } from 'c/slwcAssetAllocationService';
import { skedUtils, newToast } from 'c/slwcUtils';
import fetchRecords from '@salesforce/apex/slwcManageAssestAssignment.fetchRecords';

const columns = [
    {label: 'NAME', fieldName: 'Name' },
    {label: 'REGION', fieldName: 'sked_Primary_Region__r.Name' },
    {label: 'PHONE', fieldName: 'Phone' }
];

export default class SlwcServiceUsersAssignment extends LightningElement {
    @track isOpenedModal;
    @track configData = {};
    @track params = {};
    @track datatable = {
        configs: {
            columns: columns,
            maxRowSelection: 1
        }
    };

    @api recordId;
    @api selectedIds;

    /* INITIALIZE */

    connectedCallback() {
        this.initialize();
        this.handleSearch();
    }

    initialize() {
        this.getConfigData();
    }

    getConfigData() {
        skedUtils.getRegionList()
            .then(result => {
                this.configData.regionList = [];
                result.forEach(item => {
                    this.configData.regionList.push({ label: item.name, value: item.id });
                });
            });
    }

    /* FILTER METHODS */

    handleChange(evt) {
        switch (evt.target.name) {
            case 'serviceUserName':
                this.params.serviceUserName = evt.target.value;
                break;
            case 'region':
                this.params.regionId = evt.target.value;
                break;
            default:
                break;
        }
        this.handleSearch();
    }

    handleSearch() {
        let params = {};
        params.objectAPI = 'Account';
        params.fields = [
            'Id',
            'Name', 
            'Phone', 
            'sked_Primary_Region__r.Name'
        ];
        params.conditions = [];
        params.orderBy = ['Name'];
        if (this.params.serviceUserName) {
            params.conditions.push('Name LIKE \'%' + this.params.serviceUserName + '%\'');
        }
        if (this.params.regionId) {
            params.conditions.push('sked_Primary_Region__c = \'' + this.params.regionId + '\'');
        }
        
        fetchRecords({ model: params })
            .then(result => {
                this.datatable.data = skedUtils.flatten(result);
            })
            .catch(error => {
                this.dispatchEvent(newToast('ERROR', error.body.message, 'error'));
            });
    }
    
    /* DATATABLE METHODS */

    getSelectedRows(evt) {
        this.selectedIds = [];
        evt.detail.forEach(item => {
            this.selectedIds.push(item.Id);
        });
    }

    /* MODAL METHODS */

    openModal() {
        this.isOpenedModal = true;
    }

    closeModal() {
        this.isOpenedModal = false;
    }

    saveModal(evt) {
        let request = {
            recordId: this.recordId,
            assignmentNotes: evt.detail.assignmentNotes,
            startDate: evt.detail.startDate,
            endDate: evt.detail.endDate,
            serviceUserIds: this.selectedIds
        }
        let service = new skedAssetLocationService();
        service.createAccountAssetAssignment(request)
            // eslint-disable-next-line no-unused-vars
            .then(result => {
                this.dispatchEvent(newToast('SUCCESS', 'Create Asset successfully!!!', 'success'));
                this.error = undefined;
                this.closeModal();
            })
            .catch(error => {
                this.dispatchEvent(newToast('ERROR', error.body.message, 'error'));
            });
    }
}