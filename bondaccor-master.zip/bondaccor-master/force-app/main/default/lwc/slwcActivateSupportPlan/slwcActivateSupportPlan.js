import { LightningElement, api, wire } from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent'
import { getRecord, getFieldValue, updateRecord } from 'lightning/uiRecordApi';
import { refreshApex } from '@salesforce/apex';

import ID_FIELD from '@salesforce/schema/skedHC__Support_Plan__c.Id';
import NAME_FIELD from '@salesforce/schema/skedHC__Support_Plan__c.Name';
import DESCRIPTION_FIELD from '@salesforce/schema/skedHC__Support_Plan__c.skedHC__Description__c';
import STATUS_FIELD from '@salesforce/schema/skedHC__Support_Plan__c.skedHC__Status__c';
import ACCOUNT_NAME_FIELD from '@salesforce/schema/skedHC__Support_Plan__c.skedHC__Account__r.Name';

export default class SlwcActivateSupportPlan extends LightningElement {
    @api recordId;

    @wire(getRecord, { recordId: '$recordId', fields: [NAME_FIELD, STATUS_FIELD, DESCRIPTION_FIELD, ACCOUNT_NAME_FIELD] })
    record;

    get name() {
        return getFieldValue(this.record.data, NAME_FIELD);
    }

    get description() {
        return getFieldValue(this.record.data, DESCRIPTION_FIELD);
    }

    get accountName() {
        return getFieldValue(this.record.data, ACCOUNT_NAME_FIELD);
    }

    get disabledActivate() {
        var status = getFieldValue(this.record.data, STATUS_FIELD);
        return status !== 'Draft';
    }

    get alertMessage() {
        var status = getFieldValue(this.record.data, STATUS_FIELD);
        var message;
        if (status === 'Draft') {
            message = 'Activating this Support Plan will Close all others for this Account.';
        }
        else {
            message = 'Only Draft Support Plan can be activated.';
        }
        return message;
    }

    btnCancelClicked() {
        const closeModalEvent = new CustomEvent('closemodal', {});
        // Fire the custom event
        this.dispatchEvent(closeModalEvent);
    }

    btnActivateClicked() {
        const fields = {};
        fields[ID_FIELD.fieldApiName] = this.recordId;
        fields[STATUS_FIELD.fieldApiName] = 'Active';

        const recordInput = { fields };

        updateRecord(recordInput)
            .then(() => {
                const closeModalEvent = new CustomEvent('closemodal', {});
                this.dispatchEvent(closeModalEvent);

                const showToast = new ShowToastEvent({
                    message: 'Support Plan ' + this.name + ' is activated successfully.',
                    variant : 'success'
                });
                this.dispatchEvent(showToast);
                // Display fresh data in the form
                return refreshApex(this.record);
            })
            .catch(error => {
                this.dispatchEvent(
                    new ShowToastEvent({
                        title: 'Error activating Support Plan.',
                        message: error.body.message,
                        variant: 'error'
                    })
                );
            });
    }
}