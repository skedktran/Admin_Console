import { LightningElement, api } from 'lwc';

export default class SlwcManageAssetAssignment extends LightningElement {
    @api recordId;

    handleWeekChange(evt) {
        // eslint-disable-next-line no-console
        console.log(evt.detail);
    }
}