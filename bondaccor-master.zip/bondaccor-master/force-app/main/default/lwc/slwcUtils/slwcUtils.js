import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import getRegionList from '@salesforce/apex/slwcManageAssestAssignment.getRegionList';
import getPersonCategories from '@salesforce/apex/slwcManageAssestAssignment.getPersonCategories';
import getEmploymentTypes from '@salesforce/apex/slwcManageAssestAssignment.getEmploymentTypes';

const newToast = (title, message, variant) => {
    return new ShowToastEvent({
        title: title,
        message: message,
        variant: variant,
    });
};

class skedUtils {

    static getRegionList() {
        return getRegionList();
    }

    static getPersonCategories() {
        return getPersonCategories();
    }

    static getEmploymentTypes() {
        return getEmploymentTypes();
    }

    static _flatten(target, obj, path) {
        var i, empty;
        if (obj.constructor === Object) {
            empty = true;
            // eslint-disable-next-line guard-for-in
            for (i in obj) {
                empty = false;
                skedUtils._flatten(target, obj[i], path ? path + '.' + i : i);
            }
            if (empty && path) {
                target[path] = {};
            }
        } else {
            target[path] = obj;
        }
    }

    static flatten(data) {
        var result;
        if (data.constructor === Object) {
            result = {};
            skedUtils._flatten(result, data, null);
        } else if (data.constructor === Array) {
            result = [];
            data.forEach(element => {
                result.push(skedUtils.flatten(element));
            });
        }
        return result;
    }

    static getStringFromArray(items) {
        return items.map(item => {
            return '\'' + item + '\'';
        }).join(',');
    }

}

export {
    newToast,
    skedUtils
};