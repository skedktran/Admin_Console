import { LightningElement, track, api } from 'lwc';
import { newToast } from 'c/slwcUtils';
import fetchRecords from '@salesforce/apex/slwcManageAssestAssignment.fetchRecords';

const columns = [
    {
        label: 'PERSON NAME', 
        fieldName: 'personName'
    },
    {
        label: 'TYPE', 
        fieldName: 'personType' 
    },
    {
        label: 'START DATE', 
        fieldName: 'sked_Start__c',
        type: 'date'
    },
    {
        label: 'END DATE', 
        fieldName: 'sked_End__c',
        type: 'date'
    },
    {
        label: 'ASSIGNMENT NOTE', 
        fieldName: 'sked_Assignment_Notes__c' 
    },
    {
        label: 'RETURN NOTE', 
        fieldName: 'sked_Return_Notes__c' 
    },
    {
        label: 'STATUS', 
        fieldName: 'sked_Status__c',
        cellAttributes: {
            class: {
                fieldName: 'sked_Status__c'
            }
        }
    }
];

const statuses = [
    {label: 'Assigned', fieldName: 'Assigned' },
    {label: 'Returned', fieldName: 'Returned' }
];

const assignedTo = [
    {label: 'Resource', fieldName: 'Resource' },
    {label: 'Service User', fieldName: 'Service User' }
];

export default class SlwcAssetsAssignment extends LightningElement {
    @track configData = {
        statusList: statuses,
        assignedTo: assignedTo
    };
    @track params = {};
    @track datatable = {
        configs: {
            columns: columns,
            maxRowSelection: 1,
            hideCheckboxColumn: true
        }
    };

    @api recordId;

    /* INITIALIZE */

    connectedCallback() {
        this.handleSearch();
    }

    /* FILTER METHODS */

    handleChange(evt) {
        switch (evt.target.name) {
            case 'personName':
                this.params.personName = evt.target.value;
                break;
            case 'status':
                this.params.status = evt.target.value;
                break;
            case 'assignedTo':
                this.params.assignedTo = evt.target.value;
                break;
            default:
                break;
        }
        this.handleSearch();
    }

    handleSearch() {
        let params = {};
        params.objectAPI = 'sked_Asset_Allocation__c';
        params.fields = [
            'sked_Account__c',
            'sked_Account__r.Name',
            'sked_Assignment_Notes__c',
            'sked_End__c',
            'sked_Resource__c',
            'sked_Resource__r.Name',
            'sked_Return_Notes__c',
            'sked_Start__c',
            'sked_Status__c'
        ];
        params.conditions = [];
        params.orderBy = ['Name'];
        if (this.recordId) {
            params.conditions.push('sked_Asset__c = \'' + this.params.recordId + '\'');
        }
        if (this.params.personName) {
            params.conditions.push('(sked_Account__r.Name LIKE \'%' + this.params.personName + '%\' OR sked_Resource__r.Name LIKE \'%' + this.params.personName + '%\')');
        }
        if (this.params.status) {
            params.conditions.push('sked_Status__c = \'' + this.params.status + '\'');
        }
        if (this.params.assignedTo) {
            if (this.params.assignedTo === 'Resource') {
                params.conditions.push('sked_Resource__c != null');
            } else if (this.params.assignedTo === 'Service User') {
                params.conditions.push('sked_Account__c != null');
            }
        }
        
        fetchRecords({ model: params })
            .then(result => {
                this.datatable.data = result
                    .map(row => ({ ...row, 
                        personName : row.sked_Account__c ? row.sked_Account__r.Name : row.sked_Resource__r.Name,
                        personType : row.sked_Account__c ? 'Service User' : 'Resource'
                    }));
            })
            .catch(error => {
                this.dispatchEvent(newToast('ERROR', error.body.message, 'error'));
            });
    }
}