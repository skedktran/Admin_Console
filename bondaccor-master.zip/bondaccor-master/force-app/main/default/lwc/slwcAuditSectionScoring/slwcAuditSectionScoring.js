import { LightningElement, track, api } from 'lwc';

import skedAuditQuestions from '@salesforce/apex/skedLexAuditController.getAuditQuestions';
import getAuditSetting from '@salesforce/apex/skedLexAuditController.getAuditSetting';
import SFDC_Images from '@salesforce/resourceUrl/sked_HLT_Dist';

const NUMBER_FORMAT = {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
}

const COLUMNS = [
    {
        label: 'Section Name',
        type: 'text',
        fieldName: 'name',
    },
    {
        label: 'Achievable Score',
        type: 'number',
        fieldName: 'achievableScore',
        typeAttributes: NUMBER_FORMAT
    },
    {
        label: 'Received Score',
        type: 'number',
        fieldName: 'receivedScore',
        typeAttributes: NUMBER_FORMAT
    },
    {
        label: 'Not Applicable Score',
        type: 'number',
        fieldName: 'notApplicableScore',
        typeAttributes: NUMBER_FORMAT
    },
    {
        label: 'Overall Score',
        type: 'percent',
        fieldName: 'overallScore',
        typeAttributes: NUMBER_FORMAT
    },
    {
        label: 'Overall Score Banding',
        type: 'overallScoreBanding',
        fieldName: 'overallScoreBandingImage',
        typeAttributes: {
            isNotApplicable: { fieldName: 'isNotApplicable' }
        },
    },
];

export default class SlwcAuditSectionScoring extends LightningElement {
    @track data = [];

    @track isLoading = true;

    @api recordId;

    columns = COLUMNS;

    get haveData() {
        return this.data.length > 0;
    }

    get canDisplay() {
        return this.isLoading || this.haveData;
    }

    connectedCallback() {
        Promise.all([
            skedAuditQuestions({auditId:this.recordId}),
            getAuditSetting()
        ]).then(([auditQuestions, {amberBandMinScore,blueBandMinScore,greenBandMinScore}]) => {
                // Naive GroupBy implementation
                let map = {};
                let array = [];
                auditQuestions
                    .filter(question => question.sked_Type__c === 'Scored Question')
                    .forEach(question => {
                        let {
                            sked_Audit_Section__c: name = '',
                            sked_Achievable_Score__c: achievableScore = 0, 
                            sked_Received_Score__c: receivedScore = 0, // score will be udpate automatically by Response so we don't need to care if it correct
                            sked_Response__c: response = 'N/A'
                        } = question;
                        let formattedName = name.toLowerCase();
                        let aggerate = map[formattedName];
                        let isNotApplicable = response === 'N/A';
                        if (!aggerate) {
                            map[formattedName] = aggerate = {
                                name,
                                achievableScore,
                                notApplicableScore: isNotApplicable ? achievableScore : 0,
                                receivedScore
                            };
                            array.push(aggerate)
                        } else {
                            aggerate.achievableScore += achievableScore;
                            aggerate.notApplicableScore += isNotApplicable ? achievableScore : 0;
                            aggerate.receivedScore += receivedScore;
                        }
                    });
                
                // update overallScore and overallScoreBanding based on groupBy
                array.forEach(section => {
                    if (section.achievableScore === section.notApplicableScore) {
                        section.isNotApplicable = true;
                        section.overallScore = NaN;
                    } else {
                        section.overallScore = section.receivedScore / (section.achievableScore - section.notApplicableScore);
                        
                        if (section.overallScore <= amberBandMinScore / 100 ) {
                            section.overallScoreBandingImage = `${SFDC_Images}/images/Red.png`;
                        } else if (section.overallScore <= greenBandMinScore / 100 ) {
                            section.overallScoreBandingImage = `${SFDC_Images}/images/Amber.png`;
                        } else if (section.overallScore <= blueBandMinScore / 100 ) {
                            section.overallScoreBandingImage = `${SFDC_Images}/images/Green.png`;
                        } else {
                            section.overallScoreBandingImage = `${SFDC_Images}/images/Blue.png`;
                        }
                    }
                    
                })

                this.isLoading = false;
                this.data = array;
            })
    }    
}