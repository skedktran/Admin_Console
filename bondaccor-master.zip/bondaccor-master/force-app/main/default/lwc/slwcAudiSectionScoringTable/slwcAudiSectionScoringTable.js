/* myDatatable.js */
import LightningDatatable from 'lightning/datatable';
import swlcOverallScoreBandingCell from './swlcOverallScoreBandingCell.html';

export default class SlwcAudiSectionScoreingTable extends LightningDatatable {
   static customTypes = {
       overallScoreBanding: {
           template: swlcOverallScoreBandingCell,
           typeAttributes: ['isNotApplicable']
       }
   };
}