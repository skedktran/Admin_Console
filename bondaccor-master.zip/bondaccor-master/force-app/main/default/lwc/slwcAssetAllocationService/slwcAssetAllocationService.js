import createResourceAssetAssignment from '@salesforce/apex/slwcManageAssestAssignment.createResourceAssetAssignment';
import createAccountAssetAssignment from '@salesforce/apex/slwcManageAssestAssignment.createAccountAssetAssignment';

class skedAssetLocationService {

    createResourceAssetAssignment(saveRequest) {
        return createResourceAssetAssignment({ request: saveRequest });
    }

    createAccountAssetAssignment(saveRequest) {
        return createAccountAssetAssignment({ request: saveRequest });
    }

}

export {
    skedAssetLocationService
}