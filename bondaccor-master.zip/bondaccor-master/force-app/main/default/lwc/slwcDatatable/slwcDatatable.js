import { LightningElement, api, track } from 'lwc';

export default class SlwcDatatable extends LightningElement {
    @api configs;
    @api page = 1;
    @api pageSize = 10;

    @track records;
    @track totalRecords;
    @track totalPages;

    allRecords;

    @api
    get model() {
        return this.model;
    }
    set model(value) {
        if (value) {
            this.allRecords = value;
            this.totalRecords = this.allRecords.length;
            this.totalPages = Math.ceil(this.totalRecords / this.pageSize);
            this.refreshTable();
        }
    }

    getSelectedRows(evt) {
        this.dispatchEvent(new CustomEvent('getselectedrows', { detail: evt.detail.selectedRows }));
    }

    handlePrevious() {
        this.page = (this.page > 1) ? (this.page - 1) : this.page;
        this.refreshTable();
    }

    handleNext() {
        this.page = (this.page < this.totalPages) ? (this.page + 1) : this.page;
        this.refreshTable();
    }

    handleFirst() {
        this.page = 1;
        this.refreshTable();
    }

    handleLast() {
        this.page = this.totalPages;
        this.refreshTable();
    }

    refreshTable() {
        let from = (this.page - 1) * this.pageSize;
        let to = from + this.pageSize;
        this.records = this.allRecords.slice(from, to);
    }
}