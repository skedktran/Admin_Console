import { LightningElement, track, api } from 'lwc';
import { skedResourceService } from 'c/slwcResourceService';
import { skedAssetLocationService } from 'c/slwcAssetAllocationService';
import { skedUtils, newToast } from 'c/slwcUtils';
import fetchRecords from '@salesforce/apex/slwcManageAssestAssignment.fetchRecords';

const columns = [
    {label: 'NAME', fieldName: 'Name' },
    {label: 'REGION', fieldName: 'sked__Primary_Region__r.Name' },
    {label: 'CATEGORY', fieldName: 'sked__Category__c' },
    {label: 'EMPLOYMENT TYPE', fieldName: 'sked__Employment_Type__c' },
    {label: 'TAGS', fieldName: 'tags' }
]

export default class SlwcResourcesAssignment extends LightningElement {
    @track isOpenedModal;
    @track configData = {};
    @track params = {};
    @track datatable = {
        configs: {
            columns: columns,
            maxRowSelection: 1
        }
    };

    @api recordId;
    @api selectedIds;

    /* INITIALIZE */

    connectedCallback() {
        this.initialize();
        this.handleSearch();
    }

    initialize() {
        this.getConfigData();
    }

    getConfigData() {
        Promise.all([
            skedUtils.getRegionList(),
            skedUtils.getPersonCategories(),
            skedUtils.getEmploymentTypes()
        ]).then(([regionList, categoryList, employmentTypeList]) => {
            this.configData.regionList = [];
            regionList.forEach(item => {
                this.configData.regionList.push({ label: item.name, value: item.id });
            });
            
            this.configData.categoryList = [];
            categoryList.forEach(item => {
                this.configData.categoryList.push({ label: item, value: item });
            });
            
            this.configData.employmentTypeList = [];
            employmentTypeList.forEach(item => {
                this.configData.employmentTypeList.push({ label: item, value: item });
            });
        });
    }

    /* FILTER METHODS */

    handleChange(evt) {
        let self = this;
        switch (evt.target.name) {
            case 'resourceName':
                self.params.resourceName = evt.target.value;
                break;
            case 'region':
                self.params.regionIds = [];
                evt.detail.forEach(item => {
                    self.params.regionIds.push(item.value);
                });
                break;
            case 'category':
                self.params.categories = [];
                evt.detail.forEach(item => {
                    self.params.categories.push(item.value);
                });
                break;
            case 'employmentType':
                self.params.employmentTypes = [];
                evt.detail.forEach(item => {
                    self.params.employmentTypes.push(item.value);
                });
                break;
            default:
                break;
        }
        this.handleSearch();
    }

    handleSearch() {
        let params = {};
        params.objectAPI = 'sked__Resource__c';
        params.fields = [
            'Id',
            'Name', 
            'sked__Category__c', 
            'sked__Employment_Type__c', 
            'sked__Primary_Region__r.Name',
            '(SELECT Id, sked__Tag__r.Name FROM sked__ResourceTags__r)'
        ];
        params.conditions = [];
        params.orderBy = ['Name'];
        if (this.params.resourceName) {
            params.conditions.push('Name LIKE \'%' + this.params.resourceName + '%\'');
        }
        if (this.params.regionIds && this.params.regionIds.length > 0) {
            let regionIds = skedUtils.getStringFromArray(this.params.regionIds);
            params.conditions.push('sked__Primary_Region__c IN (' + regionIds + ')');
        }
        if (this.params.categories && this.params.categories.length > 0) {
            let categories = skedUtils.getStringFromArray(this.params.categories);
            params.conditions.push('sked__Category__c IN (' + categories + ')');
        }
        if (this.params.employmentTypes && this.params.employmentTypes.length > 0) {
            let employmentTypes = skedUtils.getStringFromArray(this.params.employmentTypes);
            params.conditions.push('sked__Employment_Type__c IN (' + employmentTypes + ')');
        }

        fetchRecords({ model: params })
            .then(result => {
                let records = result
                    .map(row => ({ ...row, 
                        tags: skedResourceService.getResourceTags(row.sked__ResourceTags__r)
                    }));
                this.datatable.data = skedUtils.flatten(records);
            })
            .catch(error => {
                this.dispatchEvent(newToast('ERROR', error.body.message, 'error'));
            });
    }
    
    /* DATATABLE METHODS */

    getSelectedRows(evt) {
        this.selectedIds = [];
        evt.detail.forEach(item => {
            this.selectedIds.push(item.Id);
        });
    }

    /* MODAL METHODS */

    openModal() {
        this.isOpenedModal = true;
    }

    closeModal() {
        this.isOpenedModal = false;
    }

    saveModal(evt) {
        let request = {
            recordId: this.recordId,
            assignmentNotes: evt.detail.assignmentNotes,
            startDate: evt.detail.startDate,
            endDate: evt.detail.endDate,
            resourceIds: this.selectedIds
        }
        let service = new skedAssetLocationService();
        service.createResourceAssetAssignment(request)
            // eslint-disable-next-line no-unused-vars
            .then(result => {
                this.dispatchEvent(newToast('SUCCESS', 'Create Asset successfully!!!', 'success'));
                this.error = undefined;
                this.closeModal();
            })
            .catch(error => {
                this.dispatchEvent(newToast('ERROR', error.body.message, 'error'));
            });
    }

}