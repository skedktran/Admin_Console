/* eslint-disable @lwc/lwc/no-inner-html */
import { LightningElement, track, api } from 'lwc';
import { loadScript } from 'lightning/platformResourceLoader';
import moment from '@salesforce/resourceUrl/sked_moment';

const CLASS_NAME = {
    DISABLED: 'slds-disabled-text',
    TODAY: 'slds-is-today',
    SELECTED: 'slds-is-selected',
    SELECTED_MULTI: 'slds-is-selected-multi',
    DAYS: 'slds-day'
}

export default class SlwcDatePicker extends LightningElement {
    @api title;
    
    @track dateContext;
    @track weekValue = '';
    @track params = {};
    
    today;
    selectedDate;

    get years() {
        let result = []
        for (let i = 1900; i <= 2100; i++) {
            result.push(i);
        }
        return result;
    }

    connectedCallback () {
        Promise.all([
            loadScript(this, moment)
        ])
        .then(() => {
            self.moment.locale('uk');
            this.today = self.moment();
            this.populateParams(this.today);
            this.goToday();
        });
    }

    focusDate() {
        this.toggleCalendar();
    }

    toggleCalendar() {
        const calendar_body = this.template.querySelector('.slds-media__body');
        calendar_body.classList.toggle("slds-hide");
    }

    initialize() {
        this.params.monthText = this.dateContext.format('MMMM');
        this.generateCalendarBody();
    }

    populateParams(value) {
        this.params.day = Number(value.date());
        this.params.month = Number(value.format('M'));
        this.params.year = Number(value.format('Y'));
    }

    goToday() {
        this.selectedDate = null;
        this.dateContext = this.today.clone();
        this.populateParams(this.dateContext);
        this.initialize();
    }

    selectHandler(evt) {
        let element = evt.target;
        if (evt.target.tagName === 'SPAN') {
            element = evt.target.parentElement;
        }

        if (element.classList.contains(CLASS_NAME.DISABLED)) return;

        this.params.day = Number(element.textContent);
        this.selectedDate = self.moment({
            year: this.params.year, 
            month: this.params.month - 1, 
            day: this.params.day
        });
        this.initialize();
    }

    handleChange(evt) {
        this.params.day = 1;
        switch (evt.target.name) {
            case 'previous':
                if (this.params.month === 1) {
                    this.params.month = 12;
                    this.params.year -= 1;
                } else {
                    this.params.month -= 1;
                }
                break;
            case 'next':
                if (this.params.month === 12) {
                    this.params.month = 1;
                    this.params.year += 1;
                } else {
                    this.params.month += 1;
                }
                break;
            case 'year':
                this.params.year = Number(evt.target.value);
                break;
            default:
                break;
        }
        this.selectedDate = null;
        this.dateContext = self.moment({
            year: this.params.year, 
            month: this.params.month - 1, 
            day: this.params.day
        });
        this.initialize();
    }

    generateCalendarBody() {
        let new_body = this.createCalendarBody();

        this.body_node = this.template.querySelector('.calendar__body');
        this.body_node.innerHTML  = ''
        this.body_node.appendChild(new_body);
    }

    createCalendarBody() {
        let days = this.createDaysArray(),
            tbody = document.createDocumentFragment();

        let tr;
        for (let i = 0; i < days.length; i++) {
            if (i % 7 === 0) {
                tr = document.createElement('tr');
            } else if (i % 7 === 6) {
                tbody.appendChild(tr);
            }
            let td = document.createElement('td');
            if (days[i].classList && days[i].classList.length > 0) {
                td.classList.add(...days[i].classList);
            }

            let span = document.createElement('span');
            span.innerText = days[i].text;
            span.classList.add(CLASS_NAME.DAYS);
            td.appendChild(span);
            tr.appendChild(td);
        }
        return tbody;
    }

    setWeekValue(from_date, to_date) {
        this.weekValue = from_date.format('MM/DD/YYYY').toString() + ' - ' + to_date.format('MM/DD/YYYY').toString();
        this.dispatchEvent(new CustomEvent('change', { detail: this.weekValue }));
    }

    createDaysArray() {
        let result = [],
            currentMoment = this.dateContext.clone(),
            startOfMonth = currentMoment.clone().startOf('month'),
            endOfMonth = currentMoment.clone().endOf('month'),
            startWeek = startOfMonth.week(),
            numWeeks = self.moment.duration(endOfMonth - startOfMonth).weeks() + 1,
            selectedWeek_from,
            selectedWeek_to;

        if (this.selectedDate) {
            selectedWeek_from = this.selectedDate.clone().startOf('week');
            selectedWeek_to = this.selectedDate.clone().endOf('week');
            this.setWeekValue(selectedWeek_from, selectedWeek_to);
        }
        for (let week = startWeek; week <= startWeek + numWeeks; week++) {
            Array(7)
                .fill(0)
                .forEach((n, i) => {
                    let day = currentMoment
                        .clone()
                        .week(week)
                        .startOf('week')
                        .add(n + i, 'day');
                    let classList = [];
                    if (day.isSame(this.today, 'day')) {
                        classList.push(CLASS_NAME.TODAY);
                    } 
                    else if (day.month() !== this.dateContext.month()) {
                        classList.push(CLASS_NAME.DISABLED);
                    }
                    if (day >= selectedWeek_from && day <= selectedWeek_to) {
                        classList.push(CLASS_NAME.SELECTED);
                        classList.push(CLASS_NAME.SELECTED_MULTI);
                    }
                    result.push({
                        classList,
                        formatted: day.format('YYYY-MM-DD'),
                        text: day.format('D')
                    });
                });
        }
        return result;
    }
}