import { LightningElement, api, track } from 'lwc';

export default class SlwcMultiPickList extends LightningElement {
    @api label;
    @api name;
    @api options;
    
    @track _initializationCompleted = false;
    @track _selectedItems;
    @track _mOptions;

    renderedCallback() {
        let self = this;
        if (!this._initializationCompleted) {
            this.template.querySelector('.ms-input').addEventListener('click', function (event) {
                self.onDropDownClick(event.target);
                event.stopPropagation();
            });
            this.template.addEventListener ('click', function (event) {
                event.stopPropagation();
            });
            document.addEventListener ('click', function () {
                self.closeAllDropDown();
            });
            this._initializationCompleted = true;
            this.setPickListName();
        }
    }

    handleItemSelected(event) {
        let self = this;
        self._mOptions.forEach(function(eachItem) {
            if (eachItem.value === event.detail.item.value) {
                eachItem.selected = event.detail.selected;
            }
        });
        this.setPickListName();
        this.onItemSelected();
    }
    
    closeAllDropDown () {
        Array.from(this.template.querySelectorAll('.ms-picklist-dropdown')).forEach(function(node) {
            node.classList.remove('slds-is-open');
        });
    }

    onDropDownClick() {
        let classList = Array.from(this.template.querySelectorAll('.ms-picklist-dropdown'));
        if(!classList.includes("slds-is-open")){
            this.closeAllDropDown();
            Array.from(this.template.querySelectorAll('.ms-picklist-dropdown')).forEach(function(node) {
                node.classList.add('slds-is-open');
            });
        } else {
            this.closeAllDropDown();
        }
    }
    
    connectedCallback() {  
        this.initArray(this);
    }

    initArray(context) {
        context._mOptions = new Array();  
        context.options.forEach(function(eachItem) {
            context._mOptions.push(JSON.parse(JSON.stringify(eachItem)));
        });
    }
    
    setPickListName() {
        let selectedItems = this.getSelectedItems();
        let selections = '' ;
        if (selectedItems.length < 1) {
            selections = 'Select an Option';
        } else if (selectedItems.length > 1) {
            selections = selectedItems.length + ' Options Selected';
        } else {
            selections = selectedItems[0].label;
        }
        this._selectedItems = selections;
    }

    @api
    getSelectedItems() {
        let resArray = new Array();
        this._mOptions.forEach(function(eachItem) {
            if (eachItem.selected) {
                resArray.push(eachItem);
            }
        });
        return resArray;
    }

    onItemSelected() {
        const evt = new CustomEvent('itemselected', { detail : this.getSelectedItems()});
        this.dispatchEvent(evt);
    }
}