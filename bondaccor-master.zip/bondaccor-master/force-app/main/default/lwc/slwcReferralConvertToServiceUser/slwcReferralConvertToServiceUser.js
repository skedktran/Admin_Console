import { LightningElement, api, track } from 'lwc';
import { NavigationMixin } from 'lightning/navigation';
import getServiceUserToConvert  from '@salesforce/apex/skedLexReferralController.getServiceUserToConvert';
import checkDuplicates          from '@salesforce/apex/skedLexReferralController.checkDuplicates';
import convertToServiceUser     from '@salesforce/apex/skedLexReferralController.convertToServiceUser';

export default class slwcReferralConvertToServiceUser extends NavigationMixin(LightningElement) {
    @api recordId;
    @track columns = [
        { 
            label: 'Name', 
            fieldName: 'nameUrl' ,
            type: 'url',
            typeAttributes: {
                label: {
                    fieldName: 'name'
                },
                target: '_blank'
            }
        },
        { label: 'Birthdate', fieldName: 'birthdate' },
        { label: 'National Insurance Number', fieldName: 'nationalInsuranceNumber' }
    ];
    @track duplicates;
    @track alert;

    get isError() {
        return this.alert.type === 'error';
    }

    get isWarning() {
        return this.alert.type === 'warning';
    }

    connectedCallback() {
        this.alert = {
            type: 'warning',
            message: 'Converting...'
        }

        getServiceUserToConvert({ referralId: this.recordId })
            .then(serviceUser => {
                return checkDuplicates({ serviceUser: serviceUser });
            })
            .then(duplicatesResult => {
                if (duplicatesResult.hasDuplicates === false) {
                    return convertToServiceUser({ referralId: this.recordId });
                }

                this.duplicates = duplicatesResult.duplicates;

                return Promise.reject({
                    type: 'warning',
                    message: 'It looks as if duplicates exist for this account.'
                });
            })
            .then(account => {
                this[NavigationMixin.Navigate]({
                    type: 'standard__recordPage',
                    attributes: {
                        recordId: account.Id,
                        objectApiName: "Account",
                        actionName: "view"
                    },
                });
            })
            .catch(error => {
                if (error.type) {
                    this.alert = error;
                }
                else {
                    this.alert = {
                        type: 'error',
                        message: error.body.message
                    }
                }
            });
    }
}